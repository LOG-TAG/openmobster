/**
 * This is a generated file. Do not edit or your changes will be lost
 */

@interface OrgOpenmobsterCloudModuleAssets : NSObject
{
}
- (NSData*) moduleAsset;
@end

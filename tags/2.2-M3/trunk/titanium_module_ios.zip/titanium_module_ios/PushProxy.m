/**
 * Appcelerator Titanium Mobile
 * Copyright (c) 2009-2011 by Appcelerator, Inc. All Rights Reserved.
 * Licensed under the terms of the Apache Public License
 * Please see the LICENSE included with this distribution for details.
 */

#import "PushProxy.h"

#import "TiUtils.h"
#import "SubmitDeviceToken.h"
#import "SystemException.h"

@implementation PushProxy

+(PushProxy *) withInit
{
	PushProxy *instance = [[PushProxy alloc] init];
	instance = [instance autorelease];
	
	return instance;
}

-(void) registerDeviceToken:(id)input
{
	NSArray *parameters = (NSArray *)input;
	
	NSString *deviceTokenStr = [parameters objectAtIndex:0];
	if(deviceTokenStr == nil)
	{
		return;
	}
	
	@try 
	{
		SubmitDeviceToken *submit = [SubmitDeviceToken withInit];
		[submit submit:deviceTokenStr];
	}
	@catch (NSException * ne) 
	{
		UIAlertView *dialog = [[UIAlertView alloc] 
							   initWithTitle:@"Token Registration Error"
							   message:@"Device Token Cloud Registration Failed. Please make sure your device is activated with the Cloud using the ActivationApp. Re-start this App to start the token registration again" 
							   delegate:nil 
							   cancelButtonTitle:@"OK" otherButtonTitles:nil];
		dialog = [dialog autorelease];
		[dialog show];
	}
}

@end
#import <Foundation/Foundation.h>
#import "AbstractOperation.h"


@interface Replace : AbstractOperation 

+(id) withInit;
@end

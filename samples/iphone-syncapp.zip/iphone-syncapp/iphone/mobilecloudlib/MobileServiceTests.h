#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "MobileService.h"
#import "Request.h"
#import "Response.h"
#import "Configuration.h"

@interface MobileServiceTests : SenTestCase 
{

}

- (void) testServiceInvocation;

@end

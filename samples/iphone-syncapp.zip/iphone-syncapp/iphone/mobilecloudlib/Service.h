#import <Foundation/Foundation.h>

@interface Service : NSObject 
{
	@private
	NSString *id;
}

@property (assign) NSString *id;

@end

#import "MobileBeanTests.h"


@implementation MobileBeanTests


- (void) TestSimpleAccessors
{
	NSLog(@"Executing testSimpleAccessors");
}


@end

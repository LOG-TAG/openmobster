#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "TestBootSync.h"
#import "TestTwoWaySync.h"
#import "TestOneWayClientSync.h"
#import "TestOneWayServerSync.h"
#import "TestSlowSync.h"
#import "TestObjectStreaming.h"
#import "Bootstrapper.h"
#import "TestSuite.h"
#import "TestContext.h"
#import "Kernel.h"
#import "SyncScheduler.h"
#import "ProxyLoader.h"


@interface SyncTests : SenTestCase 
{

}
@end

#import <Foundation/Foundation.h>

@interface GeneralTools : NSObject

+(NSString *) generateUniqueId;
+(NSString *) getDeviceIdentifier;
@end


#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>


@interface SyncXMLTests : SenTestCase 
{

}
@end

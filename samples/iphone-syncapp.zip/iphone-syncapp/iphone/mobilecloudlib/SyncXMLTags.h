
#import <Foundation/Foundation.h>

extern NSString *const _Sync;
extern NSString *const _SyncML;
extern NSString *const _Meta;
extern NSString *const _MaxMsgSize;
extern NSString *const _sycml_metinf;
extern NSString *const _sycml_auth_sha;
extern NSString *const _Cred;
extern NSString *const _Type;
extern NSString *const _NextNonce;
extern NSString *const _Format;
extern NSString *const _Chal;
extern NSString *const _CmdID;
extern NSString *const _Target;
extern NSString *const _Source;
extern NSString *const _LocURI;
extern NSString *const _SyncBody;
extern NSString *const _Alert;
extern NSString *const _Delete;
extern NSString *const _Add;
extern NSString *const _Replace;
extern NSString *const _Item;
extern NSString *const _SyncHdr;
extern NSString *const _VerDTD;
extern NSString *const _VerProto;
extern NSString *const _SessionID;
extern NSString *const _MsgID;
extern NSString *const _Status;
extern NSString *const _Data;
extern NSString *const _Anchor;
extern NSString *const _Last;
extern NSString *const _Next;
extern NSString *const _Final;
extern NSString *const _MsgRef;
extern NSString *const _CmdRef;
extern NSString *const _Cmd;
extern NSString *const _TargetRef;
extern NSString *const _SourceRef;
extern NSString *const _MoreData;
extern NSString *const _Archive;
extern NSString *const _SftDel;
extern NSString *const _NumberOfChanges;
extern NSString *const _Map;
extern NSString *const _MapItem;

@interface SyncXMLTags : NSObject 
@end

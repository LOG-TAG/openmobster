#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>

#import "SyncAdapterRequest.h"
#import "SyncAdapterResponse.h"
#import "SyncAdapter.h"

@interface SyncBootstrapTests : SenTestCase 
{

}

@end

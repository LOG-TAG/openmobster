//TODO: implement this

#import "ErrorHandler.h"


@implementation ErrorHandler

+(void) handleException:(NSException *)exception
{
}

+(NSString *) generateReport
{
	return nil;
}

+(void) clearAll
{
}
@end

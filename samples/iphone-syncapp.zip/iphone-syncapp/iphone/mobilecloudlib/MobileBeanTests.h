#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "Bootstrapper.h"
#import "TestSuite.h"
#import "TestContext.h"
#import "Kernel.h"

@interface MobileBeanTests : SenTestCase 
{

}
@end

#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>

#import "StartSync.h"
#import "StartHandshake.h"
#import "DecideEndInit.h"
#import "DecideEndSync.h"
#import "StartClose.h"


@interface WorkflowTests : SenTestCase 
{

}

@end

#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>


@interface UtilTests : SenTestCase 
{
}

@end
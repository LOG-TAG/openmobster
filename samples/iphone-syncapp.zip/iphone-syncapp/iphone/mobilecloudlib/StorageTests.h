#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>


@interface StorageTests : SenTestCase 
{

}

@end

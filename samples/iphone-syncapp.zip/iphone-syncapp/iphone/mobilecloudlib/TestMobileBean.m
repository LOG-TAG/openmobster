#import "TestMobileBean.h"


@implementation TestMobileBean


-(void) testSimpleAccess 
{
    NSLog(@"Executing TestSimpleAccess.....");
	//Bootstrapper *bootstrap = [Bootstrapper withInit];
	//TestSuite *suite = [bootstrap bootstrap:@"192.168.1.101"];
	
	//Prepare the TestContext
	//TestContext *context = suite.context;
	//[context setAttribute:@"channel" :@"testServerBean"];
	
	//Prepare the tests to be executed
	/*[suite addTest:[TestSlowSync withInit]];
	[suite addTest:[TestBootSync withInit]];
	[suite addTest:[TestTwoWaySync withInit]];
	[suite addTest:[TestOneWayServerSync withInit]];
	[suite addTest:[TestOneWayClientSync withInit]];
	[suite addTest:[TestObjectStreaming withInit]];
	
	
	//Start test execution
	[suite execute];*/
}
@end

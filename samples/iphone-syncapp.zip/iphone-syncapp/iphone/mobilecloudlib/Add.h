#import <Foundation/Foundation.h>
#import "AbstractOperation.h"

@interface Add : AbstractOperation

+(id) withInit;
@end

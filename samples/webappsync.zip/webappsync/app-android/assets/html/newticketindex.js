//Show the home screen
var homeScn = home();
stack.push(homeScn);

//Now push the new ticket screen
var newTicketScn = newTicket();
stack.push(newTicketScn);
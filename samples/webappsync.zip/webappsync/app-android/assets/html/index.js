//Show the home screen
homeScn = home();
stack.push(homeScn);
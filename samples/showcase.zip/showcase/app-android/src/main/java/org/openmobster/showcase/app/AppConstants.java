/**
 * 
 */
package org.openmobster.showcase.app;

/**
 * @author openmobster
 *
 */
public interface AppConstants
{
	public String webappsync = "webappsync_ticket_channel";
}

/**
 * 
 */
package org.openmobster.pushmail.app;

/**
 * @author openmobster
 *
 */
public interface AppConstants
{
	public String push_mail_channel = "pushmail_channel";
}

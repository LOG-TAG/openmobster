//
//  TableViewTutorialViewController.m
//  TableViewTutorial
//
//  Created by openmobster on 2/15/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import "TableViewTutorialViewController.h"

@implementation TableViewTutorialViewController

@synthesize countries;

/*
// The designated initializer. Override to perform setup that is required before the view is loaded.
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    if ((self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil])) {
        // Custom initialization
    }
    return self;
}
*/

/*
// Implement loadView to create a view hierarchy programmatically, without using a nib.
- (void)loadView {
}
*/


/*
// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}
*/

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
}

 // Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
-(void)viewDidLoad 
{
	[super viewDidLoad];
	
	self.countries = [NSMutableArray array];
	[countries addObject:@"USA"];
	[countries addObject:@"Russia"];
	[countries addObject:@"France"];
	[countries addObject:@"China"];
	[countries addObject:@"Italy"];
}


- (void)dealloc 
{
	[countries release];
    [super dealloc];
}

//-------------UITableViewDataSource-------------------------------------------------------
//Callback to check how many rows in a table
-(NSInteger) tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section 
{
	return [countries count];
}

//Callback to setup an individual table cell for display
-(UITableViewCell *) tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath 
{
	//Setup the UITableCell to be rendered
	UITableViewCell *local = [tableView dequeueReusableCellWithIdentifier:@"country-table"];
	if(local == nil)
	{
		local = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault
								reuseIdentifier:@"country-table"];
		local = [local autorelease];
	}
	
	int index = indexPath.row;
	
	//Find the country that needs to be displayed
    NSString *country = [countries objectAtIndex:index];
	
	//Set the cell value to the country
	local.textLabel.text = country;
	
	return local;
}
//--------------UITableViewDelegate-------------------------------------------------------------
//Event Handler in response to selecting a table item
-(void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath 
{
	//Select the item  
	[tableView deselectRowAtIndexPath:indexPath animated:YES];
	[tableView scrollToRowAtIndexPath:indexPath 
					 atScrollPosition:UITableViewScrollPositionMiddle animated:YES];
	
	int index = indexPath.row;
	
	//Find the country that was selected
    NSString *country = [countries objectAtIndex:index];
	NSString *message = [NSString stringWithFormat:@"Welcome to %@!!",country];
	
	//Construct a UIAlertView to show a message
	UIAlertView *dialog = [[UIAlertView alloc] initWithTitle:country 
						message:message delegate:nil 
						cancelButtonTitle:@"OK" otherButtonTitles:nil];
	
	dialog = [dialog autorelease];
	[dialog show];
}
@end

//
//  TableViewTutorialViewController.h
//  TableViewTutorial
//
//  Created by openmobster on 2/15/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TableViewTutorialViewController : 
UIViewController<UITableViewDataSource,UITableViewDelegate> 
{
	@private
	NSMutableArray *countries; //a list of counties to be displayed in the table
}

@property(nonatomic,retain)NSArray *countries;
@end


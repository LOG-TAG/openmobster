//
//  TableViewTutorialAppDelegate.h
//  TableViewTutorial
//
//  Created by openmobster on 2/15/11.
//  Copyright __MyCompanyName__ 2011. All rights reserved.
//

#import <UIKit/UIKit.h>

@class TableViewTutorialViewController;

@interface TableViewTutorialAppDelegate : NSObject <UIApplicationDelegate> {
    UIWindow *window;
    TableViewTutorialViewController *viewController;
}

@property (nonatomic, retain) IBOutlet UIWindow *window;
@property (nonatomic, retain) IBOutlet TableViewTutorialViewController *viewController;

@end


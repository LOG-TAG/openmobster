#import "Add.h"


@implementation Add

+(id) withInit
{
	return [[[Add alloc] init] autorelease];
}

@end

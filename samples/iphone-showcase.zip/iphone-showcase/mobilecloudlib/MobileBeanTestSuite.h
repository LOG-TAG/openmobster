#import <SenTestingKit/SenTestingKit.h>
#import <UIKit/UIKit.h>
#import "Bootstrapper.h"
#import "TestSuite.h"
#import "TestContext.h"
#import "TestSimpleAccess.h"
#import "TestArrayAccess.h"
#import "TestCRUD.h"

@interface MobileBeanTestSuite : SenTestCase 
{
}

@end

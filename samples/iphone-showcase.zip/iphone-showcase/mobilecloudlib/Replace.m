#import "Replace.h"


@implementation Replace

+(id) withInit
{
	return [[[Replace alloc] init] autorelease];
}

@end

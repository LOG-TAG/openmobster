#import "Service.h"

@implementation Service

@synthesize id;

@end

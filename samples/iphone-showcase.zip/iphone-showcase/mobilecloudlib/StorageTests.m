#import "StorageTests.h"


@implementation StorageTests

/*
- (void) testMath 
{
    NSLog(@"Starting testMath.......");
    STAssertTrue((1+1)==2, @"Compiler isn't feeling well today :-(" );
    
}
*/

@end

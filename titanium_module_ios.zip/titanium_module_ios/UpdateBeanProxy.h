//
//  UpdateBeanProxy.h
//  titanium_module_ios
//
//  Created by openmobster on 6/19/11.
//  Copyright 2011 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "TiProxy.h"
#import "MobileBean.h"
#import "TitaniumKernel.h"


@interface UpdateBeanProxy : TiProxy 
{
	@private
	MobileBean *bean;
}

@property (nonatomic,retain) MobileBean *bean;

+(UpdateBeanProxy *) withInit;

-(id) oid:(id)input;
-(id) getValue:(id)input;
-(void) setValue:(id)input;
-(void) commit:(id) input;
-(id) arrayLength:(id)input;
@end

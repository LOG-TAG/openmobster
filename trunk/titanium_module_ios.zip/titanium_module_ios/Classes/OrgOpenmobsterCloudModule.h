/**
 * Your Copyright Here
 *
 * Appcelerator Titanium is Copyright (c) 2009-2010 by Appcelerator, Inc.
 * and licensed under the Apache Public License (version 2)
 */
#import "TiModule.h"

@interface OrgOpenmobsterCloudModule : TiModule 
{
}

-(id)sync:(id)args;
-(id)rpc:(id)args;
-(id)push:(id)args;
@end
